
import java.util.Scanner;
import java.io.*;


class BinarySearchTree
{
    private ModuleTree root;

    public ModuleTree find(Integer val)
    {
        if (root != null)
            return root.find(val);
        return null;
    }


    public void insert(Integer val)
    {
        if (root == null)
            this.root = new ModuleTree(val);
        else
            root.insert(val);
    }


    public void delete(Integer val)
    {
        ModuleTree now_val = this.root;
        ModuleTree parent = this.root;
        boolean issonL = false;

        if(find(val) != null)
        {
            if (now_val == null)
                return;
            while (now_val != null && now_val.getval() != val)
            {
                parent = now_val;
                if (val < now_val.getval())
                {
                    now_val = now_val.getsonL();
                    issonL = true;
                } else
                {
                    now_val = now_val.getsonR();
                    issonL = false;
                }
            }
            if (now_val == null)
                return;
            if (now_val.getsonL() == null && now_val.getsonR() == null)
            {
                if (now_val == root)
                {
                    root = null;
                }
                else
                {
                    if (issonL)
                        parent.setsonL(null);
                    else
                        parent.setsonR(null);
                }
            }
            else if (now_val.getsonR() == null)
            {
                if (now_val == root)
                {
                    root = now_val.getsonL();
                }
                else if (issonL)
                {
                    parent.setsonL(now_val.getsonL());
                }
                else
                {
                    parent.setsonR(now_val.getsonL());
                }
            }
            else if (now_val.getsonL() == null)
            {
                if (now_val == root)
                {
                    root = now_val.getsonR();
                }
                else if (issonL)
                {
                    parent.setsonL(now_val.getsonR());
                }
                else
                {
                    parent.setsonR(now_val.getsonR());
                }
            }
            else
            {
                ModuleTree successor = getSuccessor(now_val);
                if (now_val == root)
                    root = successor;
                else if (issonL)
                {
                    parent.setsonL(successor);
                }
                else
                {
                    parent.setsonR(successor);
                }
                successor.setsonL(now_val.getsonL());
            }
        }
        else
        {
            System.out.println("Delete " +val+ " FAILED (not in the list)");
        }
    }

    private ModuleTree getSuccessor(ModuleTree node)
    {
        ModuleTree parentOfSuccessor = node;
        ModuleTree successor = node;
        ModuleTree now_val = node.getsonR();
        while (now_val != null)
        {
            parentOfSuccessor = successor;
            successor = now_val;
            now_val = now_val.getsonL();
        }
        if (successor != node.getsonR())
        {
            parentOfSuccessor.setsonL(successor.getsonR());
            successor.setsonR(node.getsonR());
        }
        return successor;
    }

    public void tio()
    {
        if (this.root != null)
            this.root.tio();
        System.out.println();
    }

}













public class ModuleTree 
{
    private Integer val;
    private ModuleTree sonL;
    private ModuleTree sonR;

    public ModuleTree(Integer val) 
    {
        this.val = val;
    }

    public void tio() 
    {
        if (this.sonL != null)
            this.sonL.tio();
        System.out.print("("+this  );
        if (this.sonR != null)
            this.sonR.tio();
        System.out.print(")");
    }

    public ModuleTree find(Integer val)
    {
        if (this.val == val)
            return this;
        if (val < this.val && sonL != null)
            return sonL.find(val);
        if (sonR != null)
            return sonR.find(val);
        return null;
    }

    public void insert(Integer val)
    {

        if(find(val) == null) 
        {
            if (val >= this.val)
            {
                if (this.sonR == null)
                    this.sonR = new ModuleTree(val);
                else
                    this.sonR.insert(val);
            } 
            else 
                {
                if (this.sonL == null)
                    this.sonL = new ModuleTree(val);
                else
                    this.sonL.insert(val);
            }
        }
        else
        {
            System.out.println("Insert " +val+ " FAILED (already in the list)");
        }
    }

    public Integer getval() 
    {
        return val;
    }

    public ModuleTree getsonL()
    {
        return sonL;
    }

    public void setsonL(ModuleTree left)
    {
        this.sonL = left;
    }

    public ModuleTree getsonR()
    {
        return sonR;
    }

    public void setsonR(ModuleTree right)
    {
        this.sonR = right;
    }

    @Override
    public String toString()
    {
        return String.valueOf(this.val);
    }

    public static void main(String args[])
    {
        File f = new File(args[0]);
        String line,val;
        BinarySearchTree t = new BinarySearchTree();
        try 
        {

            FileReader fileReader = new FileReader(f);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            StringBuffer stringBuffer = new StringBuffer();

            while ((line = bufferedReader.readLine()) != null)
            {
                stringBuffer.append(line);
                stringBuffer.append("\n");
            }

            val = stringBuffer.toString();
            String [] values = val.split("\n");

            for(int i=0;i<values.length;i++)
            {
                if(values[i].contains("I"))
                {
                    Scanner sc = new Scanner(values[i]).useDelimiter("[^0-9]+");

                    while (sc.hasNextInt())
                    {

                        t.insert(sc.nextInt());
                    }

                }
                else if(values[i].contains("D"))
                {
                    Scanner sc = new Scanner(values[i]).useDelimiter("[^0-9]+");
                    while (sc.hasNextInt())
                    {
                        t.delete(sc.nextInt());
                    }
                }
                else if(values[i].contains("P"))
                {
                    t.tio();
                }
                else
                {
                    System.out.println("Invalid operation on tree");
                }
            }
            fileReader.close();
        } 
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }
}

