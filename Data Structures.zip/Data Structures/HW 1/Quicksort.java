public class Quicksort {
    public static int comc =0;
    private static int [] random1024 = randomnumbers(1024);
    private static int [] random32768 = randomnumbers(32768);
    private static int [] random1048576 = randomnumbers(1048576);

    public static void main(String[] args) {


        int[] elements = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 43, 47, 53, 59, 61, 67, 71, 79, 83, 89, 97, 101, 103, 105, 107, 109, 111, 120, 121, 160};
        int [] r_elements= {160,121,120,111,109,107,105,103,101,97,89,83,79,71,67,61,59,53,47,43,37,31,29,23,19,17,13,11,7,5,3,2};
        int [] random32 = {192,145,678,3,4,6,88,53,2,2445,7896,33457,33446,985,2345,8866,3456,743,56,2344,556,887,9987,1234,6677,886,8899,5567,7889,543,7788,4456};

        int start=0;
        int end=elements.length - 1;
        int rend=random32.length - 1;

        System.out.println("QuickSort");
        final long startTime_sorted_quick = System.nanoTime();
        quickSort(elements,start,end);
        final long endTime_sorted_quick = System.nanoTime();
        print(elements);
        System.out.println("No. of key Comparisons Sorted : "+Quicksort.comc);
        System.out.println("Time Sorted: "+ ((endTime_sorted_quick - startTime_sorted_quick)/1e6));
        Quicksort.comc = 0;

        final long startTime_unsorted_quick = System.nanoTime();
        quickSort(r_elements,start,end);
        final long endTime_unsorted_quick = System.nanoTime();
        print(r_elements);
        System.out.println("No. of key Comparisons Reverse : "+Quicksort.comc);
        System.out.println("Time Reverse: "+ ((endTime_unsorted_quick - startTime_unsorted_quick)/1e6));
        Quicksort.comc = 0;

        final long startTime_r32_quick = System.nanoTime();
        quickSort(random32,start,rend);
        final long endTime_r32_quick = System.nanoTime();
        print(random32);
        System.out.println("No. of key Comparisons Random 32 : "+Quicksort.comc);
        System.out.println("Time Random32: "+ ((endTime_r32_quick - startTime_r32_quick)/1e6));
        Quicksort.comc = 0;

        final long startTime_r1024_quick = System.nanoTime();
        quickSort(random1024,start,rend);
        final long endTime_r1024_quick = System.nanoTime();
        print(random1024);
        System.out.println("No. of key Comparisons Random 1024 : "+Quicksort.comc);
        System.out.println("Time Random1024: "+ ((endTime_r1024_quick - startTime_r1024_quick)/1e6));
        Quicksort.comc = 0;

        final long startTime_r32768_quick = System.nanoTime();
        quickSort(random32768,start,rend);
        final long endTime_r32768_quick = System.nanoTime();
        print(random32768);
        System.out.println("No. of key Comparisons Random 32768 : "+Quicksort.comc);
        System.out.println("Time Random32768: "+ ((endTime_r32768_quick - startTime_r32768_quick)/1e6));
        Quicksort.comc = 0;

        final long startTime_r1048576_quick = System.nanoTime();
        quickSort(random1048576,start,rend);
        final long endTime_r1048576_quick = System.nanoTime();
        //print(random1048576);
        System.out.println("No. of key Comparisons Random 1048576 : "+Quicksort.comc);
        System.out.println("Time Random1048576: "+ ((endTime_r1048576_quick - startTime_r1048576_quick)/1e6));
        Quicksort.comc = 0;

        System.out.println("MergeSort");
        final long startTime_sorted_merge = System.nanoTime();
        merge_sort(elements, 0, elements.length - 1);
        final long endTime_sorted_merge = System.nanoTime();
        print(elements);
        System.out.println("No. of key Comparisons Sorted : "+ Quicksort.comc);
        System.out.println("Time Sorted: "+ ((endTime_sorted_merge - startTime_sorted_merge)/1e6));
        Quicksort.comc = 0;

        final long startTime_unsorted_merge = System.nanoTime();
        merge_sort(r_elements, 0, r_elements.length - 1);
        final long endTime_unsorted_merge = System.nanoTime();
        print(r_elements);
        System.out.println("No. of key Comparisons Reverse: "+ Quicksort.comc);
        System.out.println("Time Reverse: "+ ((endTime_unsorted_merge - startTime_unsorted_merge)/1e6));
        Quicksort.comc = 0;

        final long startTime_r32_merge = System.nanoTime();
        merge_sort(random32, 0, random32.length - 1);
        final long endTime_r32_merge = System.nanoTime();
        print(random32);
        System.out.println("No. of key Comparisons Random : "+Quicksort.comc);
        System.out.println("Time Random32: "+ ((endTime_r32_merge - startTime_r32_merge)/1e6));
        Quicksort.comc = 0;

        final long startTime_r1024_merge = System.nanoTime();
        merge_sort(random1024, 0, random1024.length - 1);
        final long endTime_r1024_merge = System.nanoTime();
        print(random1024);
        System.out.println("No. of key Comparisons Random : "+Quicksort.comc);
        System.out.println("Time Random1024: "+ ((endTime_r1024_merge - startTime_r1024_merge)/1e6));
        Quicksort.comc = 0;

        final long startTime_r32768_merge = System.nanoTime();
        merge_sort(random32768, 0, random32768.length - 1);
        final long endTime_r32768_merge = System.nanoTime();
        print(random32768);
        System.out.println("No. of key Comparisons Random : "+Quicksort.comc);
        System.out.println("Time Random32768: "+ ((endTime_r32768_merge - startTime_r32768_merge)/1e6));
        Quicksort.comc = 0;

        final long startTime_r1048576_merge = System.nanoTime();
        merge_sort(random1048576, 0, random1048576.length - 1);
        final long endTime_r1048576_merge = System.nanoTime();
        //print(random1048576);
        System.out.println("No. of key Comparisons Random : "+Quicksort.comc);
        System.out.println("Time Random1048576: "+ ((endTime_r1048576_merge - startTime_r1048576_merge)/1e6));
        Quicksort.comc = 0;

        System.out.println("HeapSort");
        final long startTime_relements_heap = System.nanoTime();
        heapsort(elements);
        final long endTime_relements_heap = System.nanoTime();
        print(elements);
        System.out.println("No. of key Comparisons Sorted : "+Quicksort.comc);
        System.out.println("Time Random elements: "+ ((endTime_relements_heap - startTime_relements_heap)/1e6));
        Quicksort.comc = 0;

        
        final long startTime_rr_elements_heap = System.nanoTime();
        heapsort(r_elements);
        final long endTime_rr_elements_heap = System.nanoTime();
        print(r_elements);
        System.out.println("No. of key Comparisons Reverse : "+Quicksort.comc);
        System.out.println("Time Random r_elements: "+ ((endTime_rr_elements_heap - startTime_rr_elements_heap)/1e6));
        Quicksort.comc = 0;

        final long startTime_random32_heap = System.nanoTime();
        heapsort(random32);
        final long endTime_random32_heap = System.nanoTime();
        print(random32);
        System.out.println("No. of key Comparisons random32 : "+Quicksort.comc);
        System.out.println("Time Random random32: "+ ((endTime_random32_heap - startTime_random32_heap)/1e6));
        Quicksort.comc = 0;

        final long startTime_random1024_heap = System.nanoTime();
        heapsort(random1024);
        final long endTime_random1024_heap = System.nanoTime();
        print(random1024);
        System.out.println("No. of key Comparisons random1024 : "+Quicksort.comc);
        System.out.println("Time Random random1024: "+ ((endTime_random1024_heap - startTime_random1024_heap)/1e6));
        Quicksort.comc = 0;

        final long startTime_random32768_heap = System.nanoTime();
        heapsort(random32768);
        final long endTime_random32768_heap = System.nanoTime();
        print(random32768);
        System.out.println("No. of key Comparisons random32768 : "+Quicksort.comc);
        System.out.println("Time Random random32768: "+ ((endTime_random32768_heap - startTime_random32768_heap)/1e6));
        Quicksort.comc = 0;

        final long startTime_random1048576_heap = System.nanoTime();
        heapsort(random1048576);
        final long endTime_random1048576_heap = System.nanoTime();
        //print(random1048576);
        System.out.println("No. of key Comparisons random1048576 : "+Quicksort.comc);
        System.out.println("Time Random random1048576: "+ ((endTime_random1048576_heap - startTime_random1048576_heap)/1e6));
        Quicksort.comc = 0;


    }

    public static int[] randomnumbers (int a)
    {

        int count = 0;
        int [] ranval = new int[a];
        for (int i = 0; i < a; i++)
        {

            ranval[count] = (int) (Math.random() * 5000000);
            count++;

        }
        return ranval;
    }


    public static boolean compare(int x,int y) {
        Quicksort.comc++;
        if( x < y){
            return true;
        }else
        {
            return false;
        }
    }
    public static void quickSort(int elements[],int start,int end) {
        if (start < end) {
            int pivot = partition(elements, start, end);
            quickSort(elements, start, pivot - 1);
            quickSort(elements, pivot + 1, end);
        }
    }

    public static int partition(int elements[],int start,int end){
        int pivot = elements[end];
        int i = start;
        for(int  j=start ; j<= end -1 ;j++){
            if(compare(elements[j],pivot)){
                int temp = elements[i];
                elements[i] = elements[j];
                elements[j] = temp;
                i++;
            }
        }
        elements[end] = elements[i];
        elements[i] = pivot;
        return i;
    }

    public static void merge_sort(int[] elements, int start, int end){
        if(start < end){
            int mid = (int)Math.floor((start+end)/2) ;
            merge_sort(elements, start, mid);
            merge_sort(elements, mid + 1, end);
            calib(elements, start, mid, end);
        }
    }

    public static void calib(int[] array, int start, int mid, int end){
        int part1 = mid - start + 1;
        int part2 = end - mid;
        int[] t1 = new int[part1];
        int[] t2 = new int[part2];

        for(int i = 0; i < part1; i++){
            t1[i] = array[start + i];
        }

        for(int j = 0; j < part2; j++){
            t2[j] = array[mid + 1 + j];
        }

        int i=0,j=0;
        for(int k=start;k<=end;k++){

            if ((j>=part2) || (i<part1 && compare(t1[i],t2[j]))) {
                array[k] = t1[i];
                i++;
            }else {
                array[k]=t2[j];
                j++;
            }

        }

    }

    private static void swap(int [] array, int index1, int index2) {
        int temp = array[index1];
        array[index1] = array[index2];
        array[index2] = temp;
    }

    private static void pushDown(int [] array, int index, int end) {
        int left = 2 * index + 1;
        if (left > end) {
            left = -1;
        }

        int right = 2 * index + 2;
        if (right > end) {
            right = -1;
        }
        if (left != -1 && COMPAREG(array[left], array[index])) {
            swap(array, left, index);
            pushDown(array, left, end);
        }
        if (right != -1 && COMPAREG(array[right], array[index])) {
            swap(array, right, index);
            pushDown(array, right, end);
        }
    }

    public static void heapify(int [] array, int end) {
        int index;

        if (end < 0) {
            index = -1;
        }else{
            index = (end - 1) / 2;
        }
        while (index >= 0) {
            pushDown(array, index, end);
            index--;
        }
    }

    public static void heapsort(int [] array) {
        heapify(array, array.length - 1);

        int end = array.length - 1;
        while (end > 0) {
            swap(array, 0, end);
            end--;
            pushDown(array, 0, end);
        }
    }

    public static boolean COMPAREG(int X, int Y){
        comc++;
        if(X > Y){
            return true;
        }else{
            return false;
        }

    }





    public static void print(int elements[]){
        for (int i = 0; i <elements.length; i++) {
            System.out.print(elements[i]+" ");
        }
        System.out.println();
    }
}