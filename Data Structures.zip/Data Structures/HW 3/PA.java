import java.io.*;
import java.util.Scanner;

public class PA
{

    public static void fr(String iFile,String oFile){
        try {
            int z = 21;
            int n = values(iFile);
            char[][] s = new char[n][z];

            BufferedReader br = new BufferedReader(new FileReader(iFile));
            String word;
            int i = 0;
            while ((word = br.readLine()) != null) {
                char[] temp = word.toCharArray();
                for (int j = 0; j < z; j++) {
                    if (j < temp.length) {
                        s[i][j] = temp[j];
                    } else {
                        s[i][j] = ' ';
                    }
                }
                i++;
            }
            int[] tempArr = new int[n];
            for (i = 0; i < n; i++) {
                tempArr[i] = i;
            }
            rSort(s, tempArr, z);
            fw(s,tempArr,oFile,n,z);

        } catch(IOException e){
            e.printStackTrace();
        }
    }

    public static void fw(char[][] s, int[] tempArr,String oFile,int n,int k){
        try {
            FileWriter file = new FileWriter(oFile, true);
            BufferedWriter output = new BufferedWriter(file);
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < k; j++) {
                    output.write(s[tempArr[i]][j]);
                }
                output.newLine();
            }
            output.close();
        } catch(IOException e){
            e.printStackTrace();
        }
    }
    public static void rSort(char[][] firstArray, int[] temp, int wl) {
        int len = firstArray.length;
        int rByte = 256;
        int[] P1 = new int[len];

        for (int d = wl - 1; d >= 0; d--) {
            int[] count = new int[rByte + 1];
            for (int i = 0; i < len; i++) {
                count[firstArray[temp[i]][d] + 1]++;
            }

            for (int j = 0; j < rByte; j++) {
                count[j + 1] += count[j];
            }
            for (int k = 0; k < len; k++) {
                P1[count[firstArray[temp[k]][d]]++] = temp[k];
            }
            for (int l = 0; l < len; l++) {
                temp[l] = P1[l];
            }
        }
    }

    public static int values(String fileName) throws IOException
    {
        BufferedReader zk = new BufferedReader(new FileReader(fileName));
        int z = 0;
        String xL;
        while ((xL = zk.readLine()) != null)
        {
            z++;
        }
        return z;
    }

    public static void main(String[] args) throws IOException
    {
        if (args.length !=0 && args[0].equals("f.txt") && args[1].equals("g.txt"))
        {
            fr(args[0],args[1]);
        }
        else
        {
            System.out.println("Input File Specification (Default shall be f.txt) :");
            Scanner sc= new Scanner(System.in);
            String inFile = sc.nextLine();




            System.out.println("Output File Specification (Default shall be g.txt) :");
            String outFile = sc.nextLine();
            fr(inFile,outFile);
        }
    }

}
