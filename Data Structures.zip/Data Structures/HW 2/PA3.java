import java.util.HashSet;
import java.util.Random;

public class PA3
{

    public static int comc =0;

    private static int [] random10000 = randomnumbers(10000);
    private static int [] random100000 = randomnumbers(100000);
    private static int [] random1000000 = randomnumbers(1000000);

    public static void main(String[] args)
    {
        int [] c1 = random10000.clone();
        int [] c2 = random100000.clone();
        int [] c3 = random1000000.clone();
        System.out.println("Algorithm SELECT1");
        int r1 = 10000; int k1 = r1/2;
        final long startTime_sorted_select11 = System.nanoTime();
        int a1=select1(c1, k1, 0, c1.length-1);
        System.out.println("Total Number of Elements are n = "+r1);
        System.out.println("The Element on position k = "+k1+ " is A[k]= "+a1);
        final long endTime_sorted_select11 = System.nanoTime();
        System.out.println("No. of key Comparisons Sorted : "+PA3.comc);
        System.out.println("Time Sorted: "+ ((endTime_sorted_select11 - startTime_sorted_select11)/1e6));
        PA3.comc = 0;

        //System.out.println("Algorithm SELECT1");
        int r2 = 100000;int k2 = r2/2;
        final long startTime_sorted_select12 = System.nanoTime();
        int a2=select1(c2, k2, 0, c2.length-1);
        System.out.println("Total Number of Elements are n = "+r2);
        System.out.println("The Element on position k = "+k2+ " is A[k]= "+a2);
        final long endTime_sorted_select12 = System.nanoTime();
        System.out.println("No. of key Comparisons Sorted : "+PA3.comc);
        System.out.println("Time Sorted: "+ ((endTime_sorted_select12 - startTime_sorted_select12)/1e6));
        PA3.comc = 0;

        //System.out.println("Algorithm SELECT1");
        int r3 = 1000000; int k3 = r3/2;
        final long startTime_sorted_select13 = System.nanoTime();
        int a3=select1(c3, k3, 0, c3.length-1);
        System.out.println("Total Number of Elements are n = "+r3);
        System.out.println("The Element on position k = "+k3+ " is A[k]= "+a3);
        final long endTime_sorted_select13 = System.nanoTime();
        System.out.println("No. of key Comparisons Sorted : "+PA3.comc);
        System.out.println("Time Sorted: "+ ((endTime_sorted_select13 - startTime_sorted_select13)/1e6));
        PA3.comc = 0;





        //System.out.println("Algorithm SELECT3");
        int [] mm = {1,35,97,10,180};
        int is1 = isort(mm, 3);
        //System.out.println("The value is "+ is1);



        Integer [] input = new Integer[random10000.length];
        Median m1 = new Median();
        //int [] input={};
        for(int i=0;i<random10000.length;i++)
        {
            input[i] = random10000[i];
        }


        System.out.println("Algorithm SELECT3");
        int r7 = 10000; int k7 = r1/2;
        final long startTime_sorted_select31 = System.nanoTime();
        SELECT3(c1,0,c1.length-1,c1.length/2);
        System.out.println("Total Number of Elements are n = "+r7);
        System.out.println("The Element on position k = "+k7+ " is A[k]= "+a1);
        final long endTime_sorted_select31 = System.nanoTime();
        System.out.println("No. of key Comparisons Sorted : "+PA3.comc);
        System.out.println("Time Sorted: "+ ((endTime_sorted_select31 - startTime_sorted_select31)/1e6));
        PA3.comc = 0;

        //System.out.println("Algorithm SELECT3");
        int r8 = 100000; int k8 = r1/2;
        final long startTime_sorted_select32 = System.nanoTime();
        SELECT3(c2,0,c2.length-1,c2.length/2);
        System.out.println("Total Number of Elements are n = "+r8);
        System.out.println("The Element on position k = "+k7+ " is A[k]= "+a2);
        final long endTime_sorted_select32 = System.nanoTime();
        System.out.println("No. of key Comparisons Sorted : "+PA3.comc);
        System.out.println("Time Sorted: "+ ((endTime_sorted_select32 - startTime_sorted_select32)/1e6));
        PA3.comc = 0;

        //System.out.println("Algorithm SELECT3");
        int r9 = 1000000; int k9 = r1/2;
        final long startTime_sorted_select33 = System.nanoTime();
        SELECT3(c3,0,c3.length-1,c3.length/2);
        System.out.println("Total Number of Elements are n = "+r9);
        System.out.println("The Element on position k = "+k9+ " is A[k]= "+a3);
        final long endTime_sorted_select33 = System.nanoTime();
        System.out.println("No. of key Comparisons Sorted : "+PA3.comc);
        System.out.println("Time Sorted: "+ ((endTime_sorted_select33 - startTime_sorted_select33)/1e6));
        PA3.comc = 0;

        PA3 s = new PA3();
        s.g1();



    }
    public void g1() {

        System.out.println("Algorithm SELECT2");
        int r4 = 10000; int k4 = r4/2;
        final long startTime_sorted_select21 = System.nanoTime();
        select2(random10000, r4);
        System.out.println("Total Number of Elements are n = "+r4);
        System.out.println("The Element on position k = "+k4+ " is A[k]= "+a1);
        final long endTime_sorted_select21 = System.nanoTime();
        System.out.println("No. of key Comparisons Sorted : "+PA3.comc);
        System.out.println("Time Sorted: "+ ((endTime_sorted_select21 - startTime_sorted_select21)/1e6));
        PA3.comc = 0;


        //System.out.println("Algorithm SELECT2");
        int r5 = 100000; int k5 = r5/2;
        final long startTime_sorted_select22 = System.nanoTime();
        select2(random100000, r5);
        System.out.println("Total Number of Elements are n = "+r5);
        System.out.println("The Element on position k = "+k5+ " is A[k]= "+a2);
        final long endTime_sorted_select22 = System.nanoTime();
        System.out.println("No. of key Comparisons Sorted : "+PA3.comc);
        System.out.println("Time Sorted: "+ ((endTime_sorted_select22 - startTime_sorted_select22)/1e6));
        PA3.comc = 0;


        int r6 = 100000; int k6 = r6/2;
        final long startTime_sorted_select23 = System.nanoTime();
        select2(random1000000, r6);
        System.out.println("Total Number of Elements are n = "+r6);
        System.out.println("The Element on position k = "+k5+ " is A[k]= "+a3);
        final long endTime_sorted_select23 = System.nanoTime();
        System.out.println("No. of key Comparisons Sorted : "+PA3.comc);
        System.out.println("Time Sorted: "+ ((endTime_sorted_select23 - startTime_sorted_select23)/1e6));
        PA3.comc = 0;

    }
    public int[] initializeArray(int[] x, int n) {

        Random r = new Random();
        for (int i = 0; i < n; i++) {
            x[i] = r.nextInt(n);
        }
        return x;
    }

    public void select2(int[] a, int n) {
        initialize(n);

        a2 = arrayCopy(a);

        Random r = new Random();
        int x = a.length/2;

        initializePA32(a2, n, x);



    }
    public void PA32(int[] a, int left, int right, int kth) {
        if ((right - left) < 25) {
            int b[] = new int[right - left];
            b = arrayCopy(a, left, right);
            ISSORT(b, b.length - 1);

            return;
        }
        int k = random(left, right);
        int v = a[k];
        int temp = a[left];
        a[left] = a[k];
        a[k] = temp;
        int l = left + 1;
        int r = right;
        while (l <= r) {
            while (l <= r && s2Compare(a[l], v)) {
                l++;
            }
            while (l <= r && s2Compare(v, a[r])) {
                r--;
            }
            if (compare(l,r))
            //if (l < r)
            {
                int t1 = a[l];
                a[l] = a[r];
                a[r] = t1;
                l++;
                r--;
            }
        }

        int t1 = a[left];
        a[left] = a[r];
        a[r] = t1;
        if (s2CompareE(r, kth)) {

        } else if (kth < r) {
            PA32(a, left, r - 1, kth);
        } else {
            PA32(a, r + 1, right, kth);
        }

    }
    public void initializePA32(int[] a, int n, int x) {
        System.out.println();


        PA32(a, 0, a.length - 1, x);

    }

    public int[] arrayCopy(int[] a) {
        int[] b = new int[a.length];
        for (int i = 0; i < a.length; i++) {
            b[i] = a[i];
        }
        return b;
    }


    public int[] arrayCopy(int[] a, int start, int end) {
        int size = end - start + 1;
        int[] b = new int[size];
        for (int i = start; i <= end; i++) {
            b[i - start] = a[i];
        }
//        System.out.println("Size of array : " + size);
        return b;
    }

    public void ISSORT(int[] a, int n) {

        if (n == 0) {
            return;
        }
        ISSORT(a, n - 1);
        int j = n - 1;

        while (j > 0 && iCompareTo(a[j], a[j - 1])) {
            int temp = a[j - 1];
            a[j - 1] = a[j];
            a[j] = temp;
            j--;
        }
    }

    public int random(int min, int max) {
        int random = min + (int) (Math.random() * ((max - min) + 1));
        return random;
    }


    public boolean s2CompareE(int x, int y) {
        S2++;
        return x == y;
    }

    public boolean s2Compare(int x, int y) {
        S2++;
        return x <= y;
    }

    public boolean iCompareTo(int x, int y) {
        S1++;
        return x <= y;
    }

    private static int select1(int[] a, int k, int left, int right)
    {
        int num;

        int pivot=findpivot(a,left,right);
        if(pivot==k-1){
            return a[pivot];
        }
        if(k-1<pivot)
        {

            return select1(a, k, left, pivot-1);
        }
        else {
            return select1(a, k, pivot+1, right);
        }

    }

    private static int findpivot(int[] a, int left, int right)
    {

        int pivot = a[(left+right)/2];
        while(left<right)
        {
            while(a[left]<pivot)
            {
                left++;
            }
            while(a[right]>pivot)
            {
                right--;
            }

            if(compare(left,right))
            {
                swap(a,left,right);
                left++;
                right--;
            }



        }
        return left;
    }

    private static void swap(int[] a, int i, int j)
    {

        int temp=a[i];
        a[i]=a[j];
        a[j]=temp;

    }



    //Random Number


    public static int[] randomnumbers (int a)
    {

        int count = 0;
        int [] ranval = new int[a];
        for (int i = 0; i < a; i++)
        {

            ranval[count] = (int) (Math.random() * 5000000);
            count++;

        }
        return ranval;
    }


    public static boolean compare(int x,int y)
    {
        PA3.comc++;
        if( x < y){
            return true;
        }else
        {
            return false;
        }
    }




    //QuickSort


    public static void quickSort(int elements[],int start,int end)
    {
        if (start < end)
        {
            int pivot = partition(elements, start, end);
            quickSort(elements, start, pivot - 1);
            quickSort(elements, pivot + 1, end);
        }
    }

    public static int partition(int elements[],int start,int end){
        int pivot = elements[end];
        int i = start;
        //isort(elements,8);
        for(int  j=start ; j<= end -1 ;j++){
            if(compare(elements[j],pivot)){
                int temp = elements[i];
                elements[i] = elements[j];
                elements[j] = temp;
                i++;
            }
        }
        elements[end] = elements[i];
        elements[i] = pivot;
        return i;
    }


    //Insertion Sort
    private static int isort (int [] a,int ele)
    {
        int current;
        int i,j=0;
        int tmp;
        for (i = 0; i < a.length; i++)
        {
            current = a[i];
            j = i - 1;
            while (j >= 0 && a[j] >= current)
            {
                a[j + 1] = a[j];
                j = j - 1;
            }
            a[j + 1] = current;
        }
        return a[ele];
    }


    public void initialize(int n) {

        a1 = new int[n];
        a2 = new int[n];
        a3 = new int[n];

        S2 = 0;


    }







    int median(Integer[] array)
    {
        if (array.length == 1)
        {
            return array[0];
        }
        int smallerCount = 0;
        for (int i = 0 ; i < array.length ; i++)
        {
            for (int j = 0 ; j < array.length ; j++)
            {
                //if (compare(array[i],array[j]))
                if (array[i] < array[j])
                {
                  smallerCount++;
                }
            }
            if (smallerCount == (array.length - 1)/2)
            {
                return array[i];
            }
            smallerCount = 0;
        }
        return -1;
    }
    int Pivot(Integer[] array)
    {
        if (array.length == 1)
        {
            return array[0];
        }

        int numGroups = array.length / 5;
        if (array.length % 5 > 0)
        {
            numGroups++;
        }
        Integer[] som = new Integer[numGroups];

        for (int i = 0 ; i < numGroups ; i++)
        {
            Integer[] subset;
            if(array.length % 5 > 0)
            {
                if (i == numGroups - 1)
                {
                    subset = new Integer[array.length % 5];
                }
                else
                {
                    subset = new Integer[5];
                }
            }
            else
            {
                subset = new Integer[5];
            }
            for (int j = 0; j < subset.length ; j++)
            {
                subset[j] = array[5*i+j];
            }

            som[i] = median(subset);
        }

        int goodPivot = DeterministicSelect(som, som.length/2 );
        return goodPivot;
    }



    int DeterministicSelect(Integer[] array, int k)
    {
        if (array.length == 1)
        {
            return array[0];
        }
        int pivot = Pivot(array);
        HashSet<Integer> A1 = new HashSet<Integer>();
        HashSet<Integer> A2 = new HashSet<Integer>();
        for (int i = 0; i < array.length ; i++)
        {

            if (array[i] < pivot)

            {

                A1.add(array[i]);
            }
            else if (array[i] > pivot)
            {
                A2.add(array[i]);
            }
        }
        if (compare(A1.size(),k))
        //if (A1.size() >= k)
        {
            return DeterministicSelect(A1.toArray(new Integer[0]) ,k);
        }
        else if (A1.size() == k-1)
        {
            return pivot;
        }
        else
        {
            return DeterministicSelect(A2.toArray(new Integer[0]) , k - A1.size() - 1);
        }
    }


    public static int findmed(int arr[],int start, int n)
    {
        //System.out.println("Start "+start );
        sort(arr,start+n,start); // Sort the array
        //printAll(arr);
        //System.out.println("element at med is "+arr[(start+start+n)/2]);
        return arr[(start +start+n)/2]; // Return middle element
    }
    public static int[] sort(int[] list, int n,int start) {
        if (start == n) {
            return list; //finished sorting
        }
        int temp;
        for (int i = n-1; i > start; i--) {
            if (compare(list[i],list[i-1]))
            //if (list[i] < list[i-1])
            {
                temp = list[i];
                list[i] = list[i-1];
                list[i-1] = temp;
            }
        }
        return sort(list, n, start+1);
    }
    public static int partition(int arr[], int l, int r, int x)
    {
        int i;
        for (i=l; i<r; i++)
            if (arr[i] == x)
                break;

        swap(arr,i, r);
        i = l;
        for (int j = l; j <= r - 1; j++)
        {
            if (arr[j] <= x)
            {
                swap(arr,i, j);
                i++;
            }
        }
        swap(arr,i, r);
        return i;

    }
    public static int SELECT3 (int arr[], int l, int r, int k) {
        //otPrint(arr);

        if (k > 0 && k <= r - l + 1)
        {

            int n = r-l+1; // Number of elements in arr[l..r]
            int i;
            int[] med = new int[(n+4)/5]; // There will be floor((n+4)/5) groups;
            for (i=0; i<n/5; i++){
                med[i] = findmed(arr,l+i*5,5);
            }
            if (i*5 < n) //For last group with less than 5 elements
            {
                med[i] = findmed(arr,l+i*5, n%5);
                i++;
            }
            //System.out.println("the med set is as following");
            //otPrint(med);
            int Mmed = (i == 1)? med[i-1]:SELECT3(med, 0, i-1, i/2);
           // System.out.println("The Value of the final med is "+Mmed);
            return -1;
        }



        return -1;
    }


    public static void otPrint(int[] num) {
        for(int i = 0; i < num.length; i++){
            System.out.print(" " + num[i]);
        }
        System.out.println();
    }

    int a[], a1[], a2[], a3[];
    int S1, S2, S3;

}